create extension if not exists pgcrypto;

create table if not exists public.business_profile (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  owner_name text,
  role text,
  description text,
  location text,
  email text,
  whatsapp text,
  website text,
  pricing_notes text,
  ai_description text,
  ai_personality text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  starting_price text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.faqs (
  id uuid primary key default gen_random_uuid(),
  question text not null,
  answer text not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.portfolio (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  url text,
  image_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.visitors (
  id uuid primary key default gen_random_uuid(),
  session_id text unique not null,
  name text,
  email text,
  phone text,
  whatsapp text,
  created_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  visitor_id uuid references public.visitors(id) on delete cascade,
  channel text not null default 'website',
  status text not null default 'active',
  lead_score integer not null default 0 check (lead_score between 0 and 100),
  human_handoff boolean not null default false,
  created_at timestamptz not null default now(),
  last_message_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  role text not null check (role in ('user','assistant','system')),
  content text not null,
  modality text not null default 'text',
  audio_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid references public.conversations(id) on delete set null,
  name text,
  business_name text,
  email text,
  phone text,
  whatsapp text,
  service text,
  budget text,
  message text,
  lead_score integer not null default 0 check (lead_score between 0 and 100),
  status text not null default 'new',
  source text not null default 'website',
  created_at timestamptz not null default now()
);

create index if not exists conversations_last_message_idx on public.conversations(last_message_at desc);
create index if not exists messages_conversation_idx on public.messages(conversation_id, created_at);
create index if not exists leads_created_idx on public.leads(created_at desc);

alter table public.business_profile enable row level security;
alter table public.services enable row level security;
alter table public.faqs enable row level security;
alter table public.portfolio enable row level security;
alter table public.visitors enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.leads enable row level security;

insert into public.business_profile
(name, owner_name, role, description, location, email, whatsapp, website, pricing_notes, ai_description, ai_personality)
select
  'JP Digital AI',
  'Eboh Emmanuel Emeke',
  'Website Designer & Developer',
  'Emmanuel builds modern SaaS-style business websites.',
  'Delta State, Nigeria',
  'jpdigitalai@gmail.com',
  '+2349030123407',
  'https://saas-web-portfolio-1r1h.vercel.app/#contact',
  'Pricing is custom based on project scope.',
  'Emmanuel is a website designer and developer who builds modern, professional SaaS-style business websites designed to help businesses establish credibility, generate leads and grow online.',
  'Friendly, confident, natural, helpful and conversational. Professional for business discussions and relaxed for normal conversation. Never pushy or robotic.'
where not exists (select 1 from public.business_profile);

insert into public.services (name, description, starting_price)
select
  'Modern SaaS Business Website',
  'A modern, responsive, professional website for a business, service company or startup.',
  'Custom'
where not exists (select 1 from public.services);

insert into public.portfolio (title, description, url)
select
  'JP Digital AI Portfolio',
  'Selected website design and development work.',
  'https://saas-web-portfolio-1r1h.vercel.app/#contact'
where not exists (select 1 from public.portfolio);
