export interface Env {
  AI: Ai;
  SUPABASE_URL: string;
  SUPABASE_SERVICE_ROLE_KEY: string;
  ADMIN_TOKEN: string;
  OWNER_EMAIL?: string;
  RESEND_API_KEY?: string;
  WHATSAPP_ACCESS_TOKEN?: string;
  WHATSAPP_VERIFY_TOKEN?: string;
  WHATSAPP_PHONE_NUMBER_ID?: string;
  WHATSAPP_GRAPH_VERSION?: string;
  ALLOWED_ORIGIN?: string;
  CHAT_MODEL?: string;
}

export interface ChatRequest {
  sessionId: string;
  message: string;
  name?: string;
  email?: string;
  phone?: string;
}

export interface AIResult {
  reply: string;
  leadScore: number;
  humanHandoff: boolean;
}
