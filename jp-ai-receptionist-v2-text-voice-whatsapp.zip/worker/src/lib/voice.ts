import type { Env } from "../types";

export async function transcribeAudio(env: Env, audio: ArrayBuffer) {
  const result = await env.AI.run("@cf/openai/whisper-large-v3-turbo", {
    audio: [...new Uint8Array(audio)],
    task: "transcribe",
    language: "en",
    vad_filter: true
  } as any);

  return String((result as any)?.text || "").trim();
}

export async function textToSpeech(env: Env, text: string) {
  const result = await env.AI.run("@cf/deepgram/aura-2-en", {
    text: text.slice(0, 1500),
    speaker: "luna",
    encoding: "mp3"
  } as any, { returnRawResponse: true });

  return result;
}
