import type { Env } from "../types";

export async function sendLeadEmail(env: Env, lead: Record<string, unknown>) {
  if (!env.RESEND_API_KEY || !env.OWNER_EMAIL) return;

  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${env.RESEND_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      from: "JP AI Receptionist <onboarding@resend.dev>",
      to: [env.OWNER_EMAIL],
      subject: `New JP Digital AI lead: ${lead.name || lead.business_name || "Visitor"}`,
      text: [
        "New lead captured",
        `Name: ${lead.name || ""}`,
        `Business: ${lead.business_name || ""}`,
        `Service: ${lead.service || ""}`,
        `Email: ${lead.email || ""}`,
        `Phone: ${lead.phone || ""}`,
        `WhatsApp: ${lead.whatsapp || ""}`,
        `Score: ${lead.lead_score || 0}`,
        `Message: ${lead.message || ""}`
      ].join("\n")
    })
  });

  if (!response.ok) console.error(await response.text());
}

export async function graphRequest(env: Env, path: string, init: RequestInit) {
  const version = env.WHATSAPP_GRAPH_VERSION || "v23.0";
  const url = `https://graph.facebook.com/${version}/${path}`;
  return fetch(url, {
    ...init,
    headers: {
      Authorization: `Bearer ${env.WHATSAPP_ACCESS_TOKEN}`,
      ...(init.headers || {})
    }
  });
}

export async function sendWhatsAppText(env: Env, to: string, text: string) {
  if (!env.WHATSAPP_ACCESS_TOKEN || !env.WHATSAPP_PHONE_NUMBER_ID) return null;

  return graphRequest(env, `${env.WHATSAPP_PHONE_NUMBER_ID}/messages`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to,
      type: "text",
      text: { body: text }
    })
  });
}

export async function downloadWhatsAppMedia(env: Env, mediaId: string) {
  const meta = await graphRequest(env, mediaId, { method: "GET" });
  if (!meta.ok) throw new Error("Could not get WhatsApp media metadata");

  const info = await meta.json() as any;
  const media = await fetch(info.url, {
    headers: { Authorization: `Bearer ${env.WHATSAPP_ACCESS_TOKEN}` }
  });

  if (!media.ok) throw new Error("Could not download WhatsApp audio");
  return media.arrayBuffer();
}
