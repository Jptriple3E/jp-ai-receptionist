import type { Env, AIResult } from "../types";
import { BASE_PROMPT, CHAT_MODEL, FALLBACK } from "../config";

function clamp(n: unknown) {
  const x = Number(n);
  return Number.isFinite(x) ? Math.max(0, Math.min(100, Math.round(x))) : 0;
}

export async function runAI(
  env: Env,
  history: Array<{ role: "system" | "user" | "assistant"; content: string }>,
  businessContext: string,
  voice = false
): Promise<AIResult> {
  const system = [
    BASE_PROMPT,
    voice ? "\nThis is a voice response. Keep it short and natural to speak." : "",
    "\nCURRENT BUSINESS KNOWLEDGE:\n",
    businessContext,
    `\nReturn ONLY JSON:
{
  "reply": "the response",
  "leadScore": 0,
  "humanHandoff": false
}

leadScore guidance:
0-30 casual
31-60 interested
61-80 qualified
81-100 ready to hire
`
  ].join("\n");

  const model = env.CHAT_MODEL || CHAT_MODEL;

  const output = await env.AI.run(model as any, {
    messages: [
      { role: "system", content: system },
      ...history.slice(-18)
    ],
    response_format: { type: "json_object" }
  } as any);

  const raw = (output as any)?.response ?? output;
  let parsed: any;

  try {
    parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
  } catch {
    parsed = { reply: FALLBACK, leadScore: 20, humanHandoff: false };
  }

  return {
    reply: String(parsed.reply || FALLBACK).slice(0, 1800),
    leadScore: clamp(parsed.leadScore),
    humanHandoff: Boolean(parsed.humanHandoff)
  };
}
