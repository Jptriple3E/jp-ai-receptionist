import type { Env, ChatRequest } from "./types";
import { db } from "./lib/supabase";
import { runAI } from "./lib/ai";
import { transcribeAudio, textToSpeech } from "./lib/voice";
import {
  sendLeadEmail,
  sendWhatsAppText,
  downloadWhatsAppMedia,
  graphRequest
} from "./lib/notifications";

const hits = new Map<string, { n: number; reset: number }>();

function cors(env: Env) {
  return {
    "Access-Control-Allow-Origin": env.ALLOWED_ORIGIN || "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
  };
}

function json(env: Env, data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...cors(env), "Content-Type": "application/json", "Cache-Control": "no-store" }
  });
}

function limited(request: Request) {
  const key = request.headers.get("CF-Connecting-IP") || "unknown";
  const now = Date.now();
  const old = hits.get(key);
  if (!old || now > old.reset) {
    hits.set(key, { n: 1, reset: now + 60_000 });
    return false;
  }
  old.n++;
  return old.n > 30;
}

async function businessContext(env: Env) {
  const c = db(env);
  const [p, s, f, port] = await Promise.all([
    c.from("business_profile").select("*").limit(1).maybeSingle(),
    c.from("services").select("name,description,starting_price").eq("active", true).limit(30),
    c.from("faqs").select("question,answer").eq("active", true).limit(50),
    c.from("portfolio").select("title,description,url").limit(30)
  ]);

  return [
    `PROFILE: ${JSON.stringify(p.data || {})}`,
    `SERVICES: ${JSON.stringify(s.data || [])}`,
    `FAQS: ${JSON.stringify(f.data || [])}`,
    `PORTFOLIO: ${JSON.stringify(port.data || [])}`
  ].join("\n");
}

async function visitor(env: Env, sessionId: string, data: any = {}) {
  const c = db(env);
  const existing = await c.from("visitors").select("*").eq("session_id", sessionId).maybeSingle();

  if (existing.data) {
    await c.from("visitors").update({
      name: data.name || existing.data.name,
      email: data.email || existing.data.email,
      phone: data.phone || existing.data.phone,
      whatsapp: data.whatsapp || existing.data.whatsapp,
      last_seen_at: new Date().toISOString()
    }).eq("id", existing.data.id);
    return existing.data.id;
  }

  const inserted = await c.from("visitors").insert({
    session_id: sessionId,
    name: data.name || null,
    email: data.email || null,
    phone: data.phone || null,
    whatsapp: data.whatsapp || null
  }).select("id").single();

  if (inserted.error) throw inserted.error;
  return inserted.data.id;
}

async function conversation(env: Env, visitorId: string, channel: string) {
  const c = db(env);
  const existing = await c.from("conversations")
    .select("*")
    .eq("visitor_id", visitorId)
    .eq("channel", channel)
    .eq("status", "active")
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (existing.data) return existing.data;

  const created = await c.from("conversations").insert({
    visitor_id: visitorId,
    channel
  }).select("*").single();

  if (created.error) throw created.error;
  return created.data;
}

async function history(env: Env, conversationId: string) {
  const { data } = await db(env).from("messages")
    .select("role,content")
    .eq("conversation_id", conversationId)
    .order("created_at", { ascending: true })
    .limit(40);

  return (data || []) as Array<{ role: "user" | "assistant" | "system"; content: string }>;
}

async function saveTurn(
  env: Env,
  conversationId: string,
  userText: string,
  reply: string,
  score: number,
  handoff: boolean,
  modality: "text" | "voice"
) {
  const c = db(env);

  await c.from("messages").insert([
    { conversation_id: conversationId, role: "user", content: userText, modality },
    { conversation_id: conversationId, role: "assistant", content: reply, modality }
  ]);

  await c.from("conversations").update({
    lead_score: score,
    human_handoff: handoff,
    last_message_at: new Date().toISOString()
  }).eq("id", conversationId);
}

async function maybeLead(env: Env, conversationId: string, body: any, score: number) {
  if (score < 60 || (!body.name && !body.email && !body.phone && !body.whatsapp)) return null;

  const c = db(env);
  const old = await c.from("leads").select("id").eq("conversation_id", conversationId).maybeSingle();
  if (old.data) return old.data.id;

  const inserted = await c.from("leads").insert({
    conversation_id: conversationId,
    name: body.name || null,
    business_name: body.businessName || null,
    email: body.email || null,
    phone: body.phone || null,
    whatsapp: body.whatsapp || null,
    service: body.service || null,
    budget: body.budget || null,
    message: body.message || null,
    lead_score: score,
    source: body.source || "website"
  }).select("*").single();

  if (inserted.error) throw inserted.error;
  await sendLeadEmail(env, inserted.data);
  return inserted.data.id;
}

async function chat(env: Env, body: ChatRequest, modality: "text" | "voice" = "text") {
  if (!body.sessionId || !body.message) throw new Error("sessionId and message are required");

  const visitorId = await visitor(env, body.sessionId, body);
  const conv = await conversation(env, visitorId, "website");
  const h = await history(env, conv.id);

  const result = await runAI(env, h.concat([{ role: "user", content: body.message }]), await businessContext(env), modality === "voice");

  await saveTurn(env, conv.id, body.message, result.reply, result.leadScore, result.humanHandoff, modality);
  const leadId = await maybeLead(env, conv.id, { ...body, source: "website" }, result.leadScore);

  return { ...result, conversationId: conv.id, leadId };
}

async function handleVoice(request: Request, env: Env) {
  const form = await request.formData();
  const file = form.get("audio");
  const sessionId = String(form.get("sessionId") || "");

  if (!(file instanceof File) || !sessionId) return json(env, { error: "audio and sessionId are required" }, 400);
  if (file.size > 8 * 1024 * 1024) return json(env, { error: "Audio must be under 8MB" }, 413);

  const audio = await file.arrayBuffer();
  const transcript = await transcribeAudio(env, audio);
  if (!transcript) return json(env, { error: "I could not hear that clearly." }, 422);

  const result = await chat(env, {
    sessionId,
    message: transcript,
    name: String(form.get("name") || ""),
    email: String(form.get("email") || ""),
    phone: String(form.get("phone") || "")
  }, "voice");

  const audioResponse = await textToSpeech(env, result.reply);
  const bytes = await audioResponse.arrayBuffer();

  return new Response(bytes, {
    headers: {
      ...cors(env),
      "Content-Type": "audio/mpeg",
      "X-Transcript": encodeURIComponent(transcript),
      "X-Reply": encodeURIComponent(result.reply)
    }
  });
}

async function handleWhatsApp(env: Env, payload: any) {
  const value = payload?.entry?.[0]?.changes?.[0]?.value;
  const message = value?.messages?.[0];
  if (!message) return;

  const from = String(message.from || "");
  if (!from) return;

  const sessionId = `whatsapp:${from}`;
  const visitorId = await visitor(env, sessionId, { whatsapp: from });
  const conv = await conversation(env, visitorId, "whatsapp");

  let text = "";

  if (message.type === "text") {
    text = String(message.text?.body || "");
  } else if (message.type === "audio") {
    const mediaId = String(message.audio?.id || "");
    if (mediaId) {
      const audio = await downloadWhatsAppMedia(env, mediaId);
      text = await transcribeAudio(env, audio);
    }
  }

  if (!text) return;

  const h = await history(env, conv.id);
  const result = await runAI(env, h.concat([{ role: "user", content: text }]), await businessContext(env), message.type === "audio");

  await saveTurn(env, conv.id, text, result.reply, result.leadScore, result.humanHandoff, message.type === "audio" ? "voice" : "text");

  await maybeLead(env, conv.id, {
    whatsapp: from,
    message: text,
    source: "whatsapp"
  }, result.leadScore);

  if (message.type === "audio") {
    const tts = await textToSpeech(env, result.reply);
    const audioBuffer = await tts.arrayBuffer();

    const upload = await graphRequest(env, `${env.WHATSAPP_PHONE_NUMBER_ID}/media`, {
      method: "POST",
      headers: { "Content-Type": "audio/mpeg" },
      body: audioBuffer
    });

    if (upload.ok) {
      const media = await upload.json() as any;
      await graphRequest(env, `${env.WHATSAPP_PHONE_NUMBER_ID}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messaging_product: "whatsapp",
          to: from,
          type: "audio",
          audio: { id: media.id }
        })
      });
    } else {
      await sendWhatsAppText(env, from, result.reply);
    }
  } else {
    await sendWhatsAppText(env, from, result.reply);
  }
}

async function webhookVerify(request: Request, env: Env) {
  const u = new URL(request.url);
  if (
    u.searchParams.get("hub.mode") === "subscribe" &&
    u.searchParams.get("hub.verify_token") === env.WHATSAPP_VERIFY_TOKEN
  ) {
    return new Response(u.searchParams.get("hub.challenge") || "", { status: 200 });
  }
  return new Response("Forbidden", { status: 403 });
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    if (request.method === "OPTIONS") return new Response(null, { headers: cors(env) });

    const u = new URL(request.url);

    try {
      if (u.pathname === "/api/health" && request.method === "GET")
        return json(env, { ok: true, service: "JP AI Receptionist V2" });

      if (u.pathname === "/api/chat" && request.method === "POST") {
        if (limited(request)) return json(env, { error: "Too many requests" }, 429);
        const body = await request.json() as ChatRequest;
        if (body.message.length > 3000) return json(env, { error: "Message too long" }, 400);
        return json(env, await chat(env, body));
      }

      if (u.pathname === "/api/voice" && request.method === "POST") {
        if (limited(request)) return json(env, { error: "Too many requests" }, 429);
        return await handleVoice(request, env);
      }

      if (u.pathname === "/api/dashboard" && request.method === "GET") {
        if (request.headers.get("Authorization") !== `Bearer ${env.ADMIN_TOKEN}`)
          return json(env, { error: "Unauthorized" }, 401);

        const c = db(env);
        const [leads, conversations] = await Promise.all([
          c.from("leads").select("*").order("created_at", { ascending: false }).limit(100),
          c.from("conversations").select("*").order("last_message_at", { ascending: false }).limit(100)
        ]);
        return json(env, { leads: leads.data || [], conversations: conversations.data || [] });
      }

      if (u.pathname === "/api/whatsapp/webhook" && request.method === "GET")
        return webhookVerify(request, env);

      if (u.pathname === "/api/whatsapp/webhook" && request.method === "POST") {
        const payload = await request.json();
        await handleWhatsApp(env, payload);
        return new Response("EVENT_RECEIVED", { status: 200 });
      }

      return json(env, { error: "Not found" }, 404);
    } catch (error) {
      console.error(error);
      return json(env, { error: "Internal server error" }, 500);
    }
  }
};
