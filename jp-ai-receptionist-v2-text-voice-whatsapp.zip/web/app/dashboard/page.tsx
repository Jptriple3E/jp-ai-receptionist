"use client";

import { useEffect, useState } from "react";

const API = process.env.NEXT_PUBLIC_API_URL || "";

export default function Dashboard() {
  const [token, setToken] = useState("");
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    const t = sessionStorage.getItem("jp_admin_token") || "";
    setToken(t);
  }, []);

  async function openDashboard() {
    setError("");
    sessionStorage.setItem("jp_admin_token", token);
    const r = await fetch(`${API}/api/dashboard`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    const d = await r.json();
    if (!r.ok) return setError(d.error || "Unauthorized");
    setData(d);
  }

  return (
    <main style={{maxWidth:900,margin:"50px auto",padding:24}}>
      <h1>JP Digital AI Dashboard</h1>
      {!data ? (
        <>
          <p>Private lead and conversation dashboard.</p>
          <input style={{padding:12,width:"100%",maxWidth:500}} value={token} onChange={e=>setToken(e.target.value)} placeholder="Admin token"/>
          <br/><br/>
          <button onClick={()=>void openDashboard()} style={{padding:12}}>Open</button>
          {error && <p>{error}</p>}
        </>
      ) : (
        <>
          <h2>Recent leads ({data.leads.length})</h2>
          {data.leads.map((x:any)=><article key={x.id} style={{border:"1px solid #ddd",padding:16,margin:"10px 0",borderRadius:12}}>
            <b>{x.name || "Visitor"}</b><div>{x.business_name || ""}</div><div>{x.email || x.whatsapp || x.phone || ""}</div><div>Score: {x.lead_score}</div><p>{x.message || ""}</p>
          </article>)}
          <h2>Conversations ({data.conversations.length})</h2>
          {data.conversations.map((x:any)=><article key={x.id} style={{border:"1px solid #ddd",padding:16,margin:"10px 0",borderRadius:12}}>
            {x.channel} · Score {x.lead_score} · Handoff: {x.human_handoff ? "Yes" : "No"}
          </article>)}
        </>
      )}
    </main>
  );
}
