"use client";

import { useEffect, useRef, useState } from "react";

type Message = { role: "user" | "assistant"; content: string; audio?: string };
const API = process.env.NEXT_PUBLIC_API_URL || "";

function session() {
  const key = "jp_ai_session";
  let id = localStorage.getItem(key);
  if (!id) { id = crypto.randomUUID(); localStorage.setItem(key, id); }
  return id;
}

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: "Hi! I’m JP Digital AI. You can chat with me normally, ask about Emmanuel’s website services, or send me a voice message. How can I help?" }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [recording, setRecording] = useState(false);
  const recorder = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);

  async function sendText() {
    const text = input.trim();
    if (!text || loading) return;

    setInput("");
    setMessages(m => [...m, { role: "user", content: text }]);
    setLoading(true);

    try {
      const r = await fetch(`${API}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId: session(), message: text })
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error);
      setMessages(m => [...m, { role: "assistant", content: data.reply }]);
    } catch {
      setMessages(m => [...m, { role: "assistant", content: "I’m having trouble connecting right now. Please try again." }]);
    } finally { setLoading(false); }
  }

  async function startRecording() {
    if (!navigator.mediaDevices?.getUserMedia) {
      alert("Voice recording is not supported by this browser.");
      return;
    }

    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    chunks.current = [];
    const r = new MediaRecorder(stream);
    recorder.current = r;

    r.ondataavailable = e => { if (e.data.size) chunks.current.push(e.data); };
    r.onstop = async () => {
      stream.getTracks().forEach(t => t.stop());
      const blob = new Blob(chunks.current, { type: r.mimeType || "audio/webm" });
      const form = new FormData();
      form.append("audio", blob, "voice.webm");
      form.append("sessionId", session());

      setLoading(true);
      try {
        const response = await fetch(`${API}/api/voice`, { method: "POST", body: form });
        if (!response.ok) throw new Error("voice failed");

        const transcript = decodeURIComponent(response.headers.get("X-Transcript") || "");
        const reply = decodeURIComponent(response.headers.get("X-Reply") || "");
        const audio = URL.createObjectURL(await response.blob());

        if (transcript) setMessages(m => [...m, { role: "user", content: `🎙️ ${transcript}` }]);
        setMessages(m => [...m, { role: "assistant", content: reply, audio }]);

        const player = new Audio(audio);
        await player.play().catch(() => {});
      } catch {
        setMessages(m => [...m, { role: "assistant", content: "I couldn’t process that voice message. Please try again or type your message." }]);
      } finally { setLoading(false); }
    };

    r.start();
    setRecording(true);
  }

  function stopRecording() {
    recorder.current?.stop();
    recorder.current = null;
    setRecording(false);
  }

  return (
    <>
      {open && (
        <section className="chat">
          <header>
            <div><strong>JP Digital AI</strong><small>Text + Voice Assistant</small></div>
            <button onClick={() => setOpen(false)}>×</button>
          </header>

          <div className="messages">
            {messages.map((m, i) => (
              <div key={i} className={`msg ${m.role === "user" ? "user" : ""}`}>
                {m.content}
                {m.audio && <audio controls src={m.audio} />}
              </div>
            ))}
            {loading && <div className="msg">Thinking…</div>}
          </div>

          <form onSubmit={e => { e.preventDefault(); void sendText(); }}>
            <input value={input} onChange={e => setInput(e.target.value)} placeholder="Type a message..." maxLength={3000} />
            <button type="submit" disabled={loading}>Send</button>
          </form>

          <button
            className={`mic ${recording ? "recording" : ""}`}
            onClick={() => recording ? stopRecording() : void startRecording()}
            disabled={loading}
          >
            {recording ? "■ Stop voice" : "🎙️ Send voice"}
          </button>
        </section>
      )}

      {!open && <button className="launcher" onClick={() => setOpen(true)}>✦ Ask JP AI</button>}
    </>
  );
}
